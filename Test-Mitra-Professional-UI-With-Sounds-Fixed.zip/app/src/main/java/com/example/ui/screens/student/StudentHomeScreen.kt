package com.example.ui.screens.student

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueryBuilder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SessionManager
import com.example.data.model.EnrichedResult
import com.example.data.model.TestItem
import com.example.data.model.User
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.MitraPrimaryButton
import com.example.ui.components.MitraSuccessButton
import com.example.ui.components.OfflineErrorCard
import com.example.ui.components.TestMitraTopBar
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraGreenLight
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraTextMuted
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import kotlinx.coroutines.launch
import com.example.util.AppSoundManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentHomeScreen(
    user: User,
    repository: TestMitraRepository,
    sessionManager: SessionManager,
    onStartTest: (testId: Long, testName: String, duration: Int) -> Unit,
    onLogout: () -> Unit
) {
    var currentUserState by remember { mutableStateOf(user) }
    var testsList by remember { mutableStateOf<List<TestItem>>(emptyList()) }
    var completedResultsMap by remember { mutableStateOf<Map<Long, EnrichedResult>>(emptyMap()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var sessionInvalidMessage by remember { mutableStateOf<String?>(null) }
    var testSearchQuery by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    fun verifyAndLoadData() {
        isLoading = true
        errorMessage = null
        sessionInvalidMessage = null
        scope.launch {
            val userId = currentUserState.id ?: 0L
            val currentDeviceId = sessionManager.getDeviceId()

            // 1. Verify User Session in Supabase & reload updated student name
            if (userId > 0) {
                val sessionRes = repository.verifyUserSession(userId, currentDeviceId)
                if (sessionRes is Resource.Success) {
                    currentUserState = sessionRes.data
                    sessionManager.saveUser(sessionRes.data)
                } else if (sessionRes is Resource.Error && !sessionRes.isNetworkError) {
                    isLoading = false
                    sessionInvalidMessage = "Session is invalid. Please log in again.\n(Account removed or active on another device)"
                    return@launch
                }
            }

            // 2. Load Tests (sorted by newest-to-oldest, id descending)
            val testsRes = repository.getTests()
            if (testsRes is Resource.Success) {
                // Filter active tests and sort by id descending (Newest first)
                testsList = testsRes.data.filter { it.isTestActive }.sortedByDescending { it.id ?: 0L }
            } else if (testsRes is Resource.Error) {
                errorMessage = testsRes.message
            }

            // 3. Load Student Submitted Results
            val resultsRes = repository.getStudentResults(userId, currentUserState.mobileNumber)
            if (resultsRes is Resource.Success) {
                completedResultsMap = resultsRes.data.associateBy { it.testId }
            }

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        verifyAndLoadData()
    }

    // Display student name with mobile fallback
    val studentDisplayName = if (!currentUserState.name.isNullOrBlank()) {
        currentUserState.name!!
    } else {
        currentUserState.mobileNumber
    }

    // Filtered tests based on search query (by Name, Date, or Day)
    val filteredTests = remember(testsList, testSearchQuery) {
        if (testSearchQuery.isBlank()) {
            testsList
        } else {
            testsList.filter { it.matchesSearch(testSearchQuery) }
        }
    }

    Scaffold(
        topBar = {
            TestMitraTopBar(
                title = "TEST MITRA",
                subtitle = "Student: $studentDisplayName",
                userRole = "Student",
                onRefresh = { verifyAndLoadData() },
                onLogout = {
                    scope.launch {
                        repository.clearUserDeviceId(currentUserState.id ?: 0L)
                        sessionManager.clearSession()
                        onLogout()
                    }
                }
            )
        },
        containerColor = MitraBgLight,
        modifier = Modifier
            .fillMaxSize()
            .testTag("student_home_screen")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MitraBgLight)
                .padding(innerPadding)
        ) {
            when {
                isLoading && testsList.isEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(
                                color = MitraNavyPrimary,
                                strokeWidth = 3.5.dp
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Loading tests from Supabase...",
                                color = MitraTextSecondary,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
                errorMessage != null -> {
                    OfflineErrorCard(
                        errorMessage = errorMessage,
                        onRetry = { verifyAndLoadData() }
                    )
                }
                else -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        // Student Profile Greeting Card
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Surface(
                                        modifier = Modifier.size(40.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        color = MitraNavyPrimary.copy(alpha = 0.1f)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.Person,
                                                contentDescription = null,
                                                tint = MitraNavyPrimary,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f, fill = false)) {
                                        Text(
                                            text = studentDisplayName,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MitraTextPrimary,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = "Student Portal",
                                            fontSize = 12.sp,
                                            color = MitraTextSecondary
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = MitraGreenLight
                                ) {
                                    Text(
                                        text = "${testsList.size} Active Tests",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MitraGreen,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }

                        // Feature 2: Simple Test Search at top of Test section
                        OutlinedTextField(
                            value = testSearchQuery,
                            onValueChange = { testSearchQuery = it },
                            placeholder = { Text("Search tests by name, date or day...") },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = "Search", tint = MitraNavyPrimary)
                            },
                            trailingIcon = {
                                if (testSearchQuery.isNotBlank()) {
                                    IconButton(onClick = { AppSoundManager.playClick(); testSearchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .testTag("student_test_search_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MitraNavyPrimary,
                                unfocusedBorderColor = MitraBorder,
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White
                            )
                        )

                        if (filteredTests.isEmpty()) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 24.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Assignment,
                                        contentDescription = null,
                                        tint = MitraTextMuted,
                                        modifier = Modifier.size(52.dp)
                                    )
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text(
                                        text = if (testSearchQuery.isNotBlank()) "No tests found" else "No active tests available currently",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MitraTextPrimary,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = if (testSearchQuery.isNotBlank()) "No tests matching \"$testSearchQuery\"" else "New tests will appear here once published by admin.",
                                        fontSize = 13.sp,
                                        color = MitraTextSecondary,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    MitraPrimaryButton(
                                        text = "Refresh",
                                        onClick = { AppSoundManager.playClick(); verifyAndLoadData() }
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("tests_list"),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                itemsIndexed(filteredTests, key = { _, it -> it.id ?: 0L }) { index, test ->
                                    val testSeqNumber = testsList.indexOfFirst { it.id == test.id }.let { idx ->
                                        if (idx >= 0) testsList.size - idx else filteredTests.size - index
                                    }
                                    val completedResult = completedResultsMap[test.id ?: 0L]

                                    StudentTestCard(
                                        test = test,
                                        testSequenceNumber = testSeqNumber,
                                        completedResult = completedResult,
                                        onStartTest = {
                                            onStartTest(test.id ?: 0L, "Test $testSeqNumber: ${test.testName}", test.duration)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Session Invalid Dialog
    if (sessionInvalidMessage != null) {
        AlertDialog(
            onDismissRequest = {
                sessionManager.clearSession()
                onLogout()
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = Color.White,
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = MitraError,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Session Invalid",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MitraError
                )
            },
            text = {
                Text(
                    text = sessionInvalidMessage!!,
                    fontSize = 14.sp,
                    color = MitraTextPrimary,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "OK",
                    onClick = { AppSoundManager.playClick();
                        sessionManager.clearSession()
                        onLogout()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        )
    }
}

@Composable
private fun StudentTestCard(
    test: TestItem,
    testSequenceNumber: Int,
    completedResult: EnrichedResult?,
    totalQuestionsCount: Int = 0,
    onStartTest: () -> Unit
) {
    val isCompleted = completedResult != null

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("test_card_${test.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    // Sequential Test Badge
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MitraNavyPrimary
                        ) {
                            Text(
                                text = "Test $testSequenceNumber",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // Test Name
                    Text(
                        text = test.testName,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MitraTextPrimary,
                        softWrap = true
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (isCompleted) MitraGreenLight else MitraBgLight
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.QueryBuilder,
                            contentDescription = null,
                            tint = if (isCompleted) MitraGreen else MitraNavyPrimary,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isCompleted) "Score: ${completedResult.score.toInt()}" else "${test.duration} min",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isCompleted) MitraGreen else MitraNavyPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Dynamic Date and Duration Badge Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val formattedDate = test.getFormattedDate()
                if (!formattedDate.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF1F5F9)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = null,
                                tint = MitraNavyPrimary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = formattedDate,
                                fontSize = 12.sp,
                                color = MitraNavyPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F5F9)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.QueryBuilder,
                            contentDescription = null,
                            tint = MitraTextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${test.duration} Min",
                            fontSize = 12.sp,
                            color = MitraTextSecondary,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (isCompleted) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MitraGreenLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = MitraGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Test Completed",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraGreen
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Start / Retake Test Button
            MitraSuccessButton(
                text = if (isCompleted) "Retake Test" else "Start Test",
                onClick = onStartTest,
                icon = if (isCompleted) Icons.Default.Refresh else Icons.Default.PlayArrow,
                modifier = Modifier.fillMaxWidth(),
                height = 48.dp,
                testTag = "start_test_button_${test.id}"
            )
        }
    }
}
